                iReasoning MIB Browser

browser.bat     script for lauching MIB browser on windows
browser.sh      script for lauching MIB browser on UNIX. 
browser.app     Mac OS X application bundle. Double click on it to lauch MIB browser on Mac OS X.

